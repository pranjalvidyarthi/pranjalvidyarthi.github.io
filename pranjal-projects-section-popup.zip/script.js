// Project category filters
const filterButtons = document.querySelectorAll(".filter-btn");
const projectCards = document.querySelectorAll(".project-card");
const countNumber = document.querySelector(".count-number");

filterButtons.forEach((button) => {
  button.addEventListener("click", () => {
    const selectedFilter = button.dataset.filter;
    filterButtons.forEach((item) => item.classList.toggle("active", item === button));

    let visibleCount = 0;
    projectCards.forEach((card) => {
      const shouldShow =
        selectedFilter === "all" || card.dataset.category === selectedFilter;
      card.classList.toggle("is-hidden", !shouldShow);
      if (shouldShow) visibleCount++;
    });

    countNumber.textContent = String(visibleCount).padStart(2, "0");
  });
});

// Theme switch: remembers the visitor's choice for the current browser.
const themeToggle = document.getElementById("theme-toggle");
const themeLabel = themeToggle.querySelector(".toggle-label");
const themeIcon = themeToggle.querySelector(".toggle-icon");

function setTheme(isDark) {
  document.body.classList.toggle("dark", isDark);
  themeLabel.textContent = isDark ? "Light theme" : "Dark theme";
  themeIcon.textContent = isDark ? "☾" : "☼";
  document.querySelector('meta[name="theme-color"]').content = isDark ? "#141210" : "#eeeae5";
  try { localStorage.setItem("projects-theme", isDark ? "dark" : "light"); } catch (_) {}
}

let savedTheme = "light";
try { savedTheme = localStorage.getItem("projects-theme") || "light"; } catch (_) {}
setTheme(savedTheme === "dark");

themeToggle.addEventListener("click", () => {
  setTheme(!document.body.classList.contains("dark"));
});

// Subtle scroll reveal
const revealItems = document.querySelectorAll(".reveal");
if ("IntersectionObserver" in window) {
  const observer = new IntersectionObserver((entries, obs) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
        obs.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });
  revealItems.forEach((item) => observer.observe(item));
} else {
  revealItems.forEach((item) => item.classList.add("visible"));
}

// Project information used by the details popup.
// Replace the example URLs with your own live demo and GitHub links.
const projectDetails = {
  "The Creative Coder": {
    number: "01 — PERSONAL WEBSITE",
    category: "PERSONAL PORTFOLIO · 2026",
    image: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1500&q=85",
    description: "A personal corner of the internet to share my work, experiments, and journey in tech.",
    idea: "Build a portfolio that feels personal, expressive, and easy to explore instead of looking like a generic template.",
    built: "A responsive portfolio with an interactive theme switch, smooth scrolling, an introduction, skills, and a selected-work section.",
    stack: ["HTML", "CSS", "JavaScript"],
    live: "#",
    source: "https://github.com/pranjalvidyarthi"
  },
  "ViChat": {
    number: "02 — WEB APPLICATION",
    category: "REAL-TIME CHAT APP",
    image: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=1200&q=85",
    description: "A real-time messaging experience focused on simple, smooth communication.",
    idea: "Create a clean place for people to communicate with a straightforward, familiar interface.",
    built: "A chat application concept with authentication and real-time messaging functionality.",
    stack: ["Next.js", "Tailwind CSS", "Clerk", "Stream Chat"],
    live: "#",
    source: "https://github.com/pranjalvidyarthi/ViChat"
  },
  "Gesture Control": {
    number: "03 — CREATIVE EXPERIMENT",
    category: "COMPUTER VISION EXPERIMENT",
    image: "https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1200&q=85",
    description: "Controlling everyday desktop actions using hand gestures and computer vision.",
    idea: "Explore a more natural way to interact with a computer without relying on a mouse for every action.",
    built: "A Python experiment using hand landmarks to map gestures to desktop controls such as volume and media playback.",
    stack: ["Python", "OpenCV", "MediaPipe", "PyCAW"],
    live: "#",
    source: "https://github.com/pranjalvidyarthi"
  }
};

const projectModal = document.getElementById("project-modal");
const modalPanel = projectModal.querySelector(".modal-panel");
const modalImage = document.getElementById("modal-image");
const modalTitle = document.getElementById("modal-title");
const modalCategory = document.getElementById("modal-category");
const modalNumber = document.getElementById("modal-number");
const modalDescription = document.getElementById("modal-description");
const modalIdea = document.getElementById("modal-idea");
const modalBuilt = document.getElementById("modal-built");
const modalTags = document.getElementById("modal-tags");
const modalLive = document.getElementById("modal-live");
const modalSource = document.getElementById("modal-source");
let lastFocusedElement = null;

function openProjectModal(projectName, trigger) {
  const project = projectDetails[projectName];
  if (!project) return;

  lastFocusedElement = trigger;
  modalTitle.textContent = projectName;
  modalCategory.textContent = project.category;
  modalNumber.textContent = project.number;
  modalDescription.textContent = project.description;
  modalIdea.textContent = project.idea;
  modalBuilt.textContent = project.built;
  modalImage.src = project.image;
  modalImage.alt = projectName + " project preview";
  modalTags.replaceChildren();

  project.stack.forEach((technology) => {
    const tag = document.createElement("span");
    tag.textContent = technology;
    modalTags.appendChild(tag);
  });

  setProjectLink(modalLive, project.live);
  setProjectLink(modalSource, project.source);

  projectModal.classList.add("is-open");
  projectModal.setAttribute("aria-hidden", "false");
  document.body.classList.add("modal-open");
  window.setTimeout(() => modalPanel.focus(), 80);
}

function setProjectLink(element, url) {
  element.href = url;
  const isPlaceholder = !url || url === "#";
  element.hidden = isPlaceholder;
}

function closeProjectModal() {
  if (!projectModal.classList.contains("is-open")) return;
  projectModal.classList.remove("is-open");
  projectModal.setAttribute("aria-hidden", "true");
  document.body.classList.remove("modal-open");
  if (lastFocusedElement) lastFocusedElement.focus();
}

projectCards.forEach((card) => {
  const title = card.querySelector("h2")?.textContent.trim();
  card.querySelectorAll(".project-image, .text-link").forEach((trigger) => {
    trigger.addEventListener("click", (event) => {
      event.preventDefault();
      openProjectModal(title, trigger);
    });
  });
});

projectModal.querySelectorAll("[data-close-modal]").forEach((element) => {
  element.addEventListener("click", closeProjectModal);
});

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") closeProjectModal();

  // Keep keyboard focus inside the dialog while it is open.
  if (event.key === "Tab" && projectModal.classList.contains("is-open")) {
    const focusable = [...modalPanel.querySelectorAll('a[href]:not([hidden]), button:not([hidden])')];
    if (!focusable.length) return;
    const first = focusable[0];
    const last = focusable[focusable.length - 1];

    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  }
});
